# Bali Tours Landing Page

Simple SEO landing page for Bali tours.

## How to use
1. Upload to GitHub
2. Enable GitHub Pages
3. Replace booking links with your affiliate links
4. Insert your GetYourGuide widget

